package com.infomatics.oxfam.twat.interfaces;

public interface ItemPositionClickListener {

    void onItemClick(int position);
}
