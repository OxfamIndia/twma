package com.infomatics.oxfam.twat.util.nfc;

public interface ParsedNdefRecord {

    String str();

}