package com.infomatics.oxfam.twat.interfaces;

import com.infomatics.oxfam.twat.model.room.entity.DashboardEntity;

public interface DashboardTaskComplete {
    public void onTaskComplete(DashboardEntity dashboardEntity);
}
