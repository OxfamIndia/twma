package com.infomatics.oxfam.twat.interfaces;

public interface TextChangeCallback {
    void textAdded(boolean value);
}
