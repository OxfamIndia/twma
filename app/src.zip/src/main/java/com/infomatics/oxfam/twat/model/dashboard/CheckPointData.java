package com.infomatics.oxfam.twat.model.dashboard;

public class CheckPointData {
}
