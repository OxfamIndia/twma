package com.infomatics.oxfam.twat.interfaces;

import android.location.Location;

public interface CustomLocationListener {
    void onLocationSuccess(Location location);
}
