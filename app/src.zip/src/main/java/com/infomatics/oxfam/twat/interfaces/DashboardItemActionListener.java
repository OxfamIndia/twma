package com.infomatics.oxfam.twat.interfaces;

public interface DashboardItemActionListener {
    void onItemClick(String action, int position);
}
