package com.infomatics.oxfam.twat.model.image;

import android.graphics.Bitmap;

public class ImageModel {

    private Bitmap bitmap;

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }
}
